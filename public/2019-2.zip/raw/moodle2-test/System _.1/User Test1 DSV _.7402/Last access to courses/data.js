var data_file_38 = {
    "4": {
        "course_name": "Pavel\u00b4s Sandbox",
        "timeaccess": "tisdag, 21 mars 2017, 9:14 "
    },
    "10": {
        "course_name": "Only Quiz",
        "timeaccess": "m\u00e5ndag, 20 juni 2016, 4:17 "
    }
}