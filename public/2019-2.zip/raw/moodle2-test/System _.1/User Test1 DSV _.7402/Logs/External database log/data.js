var data_file_20 = {
    "logs": [
        {
            "name": "Message viewed",
            "description": "The user with id '2020' read a message from the user with id '5'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": null,
            "other": {
                "messageid": 28
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 5,
            "related_user_was_you": "No"
        },
        {
            "name": "Message viewed",
            "description": "The user with id '2020' read a message from the user with id '5'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": null,
            "other": {
                "messageid": 29
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 5,
            "related_user_was_you": "No"
        },
        {
            "name": "User updated",
            "description": "The user with id '0' updated the profile for the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 0,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Dashboard viewed",
            "description": "The user with id '2020' has viewed their dashboard",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Dashboard viewed",
            "description": "The user with id '2020' has viewed their dashboard",
            "timecreated": "tisdag, 21 mars 2017, 9:22 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 2020,
            "related_user_was_you": "Yes",
            "author_of_the_action_was_masqueraded": "Yes",
            "masqueradinguserid": 5,
            "masquerading_user_was_you": "No"
        }
    ]
}