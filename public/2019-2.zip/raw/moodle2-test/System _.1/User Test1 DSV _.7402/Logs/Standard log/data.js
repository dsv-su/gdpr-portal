var data_file_27 = {
    "logs": [
        {
            "name": "User password updated",
            "description": "The user with id '1' changed the password of the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 20 juni 2016, 4:17 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "forgottenreset": false
            },
            "authorid": 1,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User created",
            "description": "The user with id '1' created the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 20 juni 2016, 4:17 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 1,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User profile viewed",
            "description": "The user with id '5' viewed the profile for the user with id '2020'.",
            "timecreated": "s\u00f6ndag, 23 oktober 2016, 10:26 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Message viewed",
            "description": "The user with id '2020' read a message from the user with id '5'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": null,
            "other": {
                "messageid": 28
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 5,
            "related_user_was_you": "No"
        },
        {
            "name": "Message viewed",
            "description": "The user with id '2020' read a message from the user with id '5'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": null,
            "other": {
                "messageid": 29
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 5,
            "related_user_was_you": "No"
        },
        {
            "name": "User updated",
            "description": "The user with id '0' updated the profile for the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 0,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Dashboard viewed",
            "description": "The user with id '2020' has viewed their dashboard",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Dashboard viewed",
            "description": "The user with id '2020' has viewed their dashboard",
            "timecreated": "tisdag, 21 mars 2017, 9:22 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 2020,
            "related_user_was_you": "Yes",
            "author_of_the_action_was_masqueraded": "Yes",
            "masqueradinguserid": 5,
            "masquerading_user_was_you": "No"
        },
        {
            "name": "User updated",
            "description": "The user with id '1' updated the profile for the user with id '2020'.",
            "timecreated": "fredag, 19 januari 2018, 4:26 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 1,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Dashboard viewed",
            "description": "The user with id '2020' has viewed their dashboard",
            "timecreated": "fredag, 19 januari 2018, 4:26 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User profile viewed",
            "description": "The user with id '5' viewed the profile for the user with id '2020'.",
            "timecreated": "fredag, 8 november 2019, 11:32 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}