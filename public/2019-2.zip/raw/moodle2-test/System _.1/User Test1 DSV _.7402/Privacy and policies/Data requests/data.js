var data_file_13 = {
    "0": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Processing",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 6 december 2019, 10:20 "
    },
    "1": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Rejected",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 8 november 2019, 11:32 "
    },
    "2": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Rejected",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 8 november 2019, 1:38 "
    },
    "3": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Download ready",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "torsdag, 5 december 2019, 4:27 "
    },
    "4": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Download ready",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 6 december 2019, 9:12 "
    },
    "5": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 8 november 2019, 2:26 "
    },
    "6": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 8 november 2019, 1:45 "
    },
    "7": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 8 november 2019, 2:27 "
    },
    "8": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "m\u00e5ndag, 11 november 2019, 5:40 "
    },
    "9": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "m\u00e5ndag, 11 november 2019, 5:29 "
    },
    "10": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "m\u00e5ndag, 11 november 2019, 5:35 "
    },
    "11": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "m\u00e5ndag, 18 november 2019, 11:11 "
    },
    "12": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "torsdag, 21 november 2019, 3:13 "
    },
    "13": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "torsdag, 21 november 2019, 3:02 "
    },
    "14": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "torsdag, 21 november 2019, 3:14 "
    },
    "15": {
        "userid": "Test1 DSV",
        "type": "Export",
        "status": "Expired",
        "creationmethod": "Automatically",
        "comments": "Autocreated",
        "dpocomment": "",
        "timecreated": "fredag, 22 november 2019, 5:36 "
    }
}