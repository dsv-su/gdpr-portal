var data_file_12 = {
    "0": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "fredag, 1 juli 2016, 12:00 ",
        "statsreads": "1",
        "statswrites": "0",
        "stattype": "logins"
    },
    "1": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "fredag, 1 juli 2016, 12:00 ",
        "statsreads": "0",
        "statswrites": "0",
        "stattype": "activity"
    },
    "2": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "l\u00f6rdag, 1 april 2017, 12:00 ",
        "statsreads": "1",
        "statswrites": "0",
        "stattype": "logins"
    },
    "3": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "l\u00f6rdag, 1 april 2017, 12:00 ",
        "statsreads": "0",
        "statswrites": "0",
        "stattype": "activity"
    },
    "4": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "torsdag, 1 februari 2018, 12:00 ",
        "statsreads": "1",
        "statswrites": "0",
        "stattype": "logins"
    },
    "5": {
        "course": "ilearn2test",
        "roleid": "0",
        "timeend": "torsdag, 1 februari 2018, 12:00 ",
        "statsreads": "0",
        "statswrites": "0",
        "stattype": "activity"
    }
}