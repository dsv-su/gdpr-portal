var data_file_45 = {
    "fullname": "ilearn2test",
    "shortname": "ilearn2test",
    "idnumber": "",
    "summary": "",
    "format": "Site",
    "startdate": "torsdag, 1 januari 1970, 1:00 ",
    "enddate": "torsdag, 1 januari 1970, 1:00 "
}