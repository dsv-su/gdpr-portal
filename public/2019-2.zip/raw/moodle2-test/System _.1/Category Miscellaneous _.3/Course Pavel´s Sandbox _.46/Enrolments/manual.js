var data_file_29 = {
    "0": {
        "status": "0",
        "timecreated": "tisdag, 21 mars 2017, 9:12 ",
        "timemodified": "tisdag, 21 mars 2017, 9:12 ",
        "timestart": "tisdag, 21 mars 2017, 12:00 ",
        "timeend": "torsdag, 1 januari 1970, 1:00 "
    }
}