var data_file_46 = {
    "fullname": "Pavel\u00b4s Sandbox",
    "shortname": "Pavel's Sandbox",
    "idnumber": "",
    "summary": "",
    "format": "Topics format",
    "startdate": "m\u00e5ndag, 10 september 2012, 12:00 ",
    "enddate": "torsdag, 1 januari 1970, 1:00 "
}