var data_file_16 = {
    "logs": [
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "User enrolled in course",
            "description": "The user with id '5' enrolled the user with id '2020' using the enrolment method 'manual' in the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "enrol": "manual"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Role assigned",
            "description": "The user with id '5' assigned the role with id '1' to the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "id": 3080,
                "component": "",
                "itemid": 0
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course updated",
            "description": "The user with id '2020' updated the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:13 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": {
                "shortname": "Pavel's Sandbox",
                "fullname": "Pavel's Sandbox"
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:13 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:13 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:14 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "User profile viewed",
            "description": "The user with id '5' viewed the profile for the user with id '2020' in the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:14 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "courseid": "4",
                "courseshortname": "Pavel's Sandbox",
                "coursefullname": "Pavel\u00b4s Sandbox"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Course viewed",
            "description": "The user with id '2020' viewed the course with id '4'.",
            "timecreated": "tisdag, 21 mars 2017, 9:14 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": [],
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes",
            "author_of_the_action_was_masqueraded": "Yes",
            "masqueradinguserid": 5,
            "masquerading_user_was_you": "No"
        }
    ]
}