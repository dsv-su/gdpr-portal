var data_file_8 = {
    "name": "News forum",
    "intro": "<div class=\"no-overflow\">General news and announcements<\/div>"
}