var data_file_17 = {
    "logs": [
        {
            "name": "Subscription created",
            "description": "The user with id '5' subscribed the user with id '2020' to the forum with course module id '8'.",
            "timecreated": "tisdag, 21 mars 2017, 9:12 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "forumid": "3"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}