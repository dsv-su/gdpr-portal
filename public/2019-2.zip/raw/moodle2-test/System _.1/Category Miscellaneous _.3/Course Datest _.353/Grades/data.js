var data_file_31 = {
    "grades": [
        {
            "item": "Course total",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "timemodified": "onsdag, 7 december 2016, 4:40 "
        },
        {
            "item": "F\u00f6rberedelseuppgifter inf\u00f6r laboration 1",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": null,
            "timemodified": null
        },
        {
            "item": "F\u00f6rberedelseuppgifter inf\u00f6r laboration 2",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": null,
            "timemodified": null
        },
        {
            "item": "Inl\u00e4mning av laboration 4",
            "grade": "2.00000",
            "grade_formatted": "More work needed",
            "feedback": "<p>Test<\/p><p>This is test<\/p><p>Some text<\/p><p>Some added text<\/p>",
            "information": "",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "timemodified": "onsdag, 7 december 2016, 4:40 "
        },
        {
            "item": "FX H\u00e5rdvara",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": null,
            "timemodified": null
        },
        {
            "item": "FX N\u00e4tverk",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": null,
            "timemodified": null
        },
        {
            "item": "FX Operativsystem",
            "grade": null,
            "grade_formatted": "-",
            "feedback": "",
            "information": "",
            "timecreated": null,
            "timemodified": null
        },
        {
            "item": "Category total",
            "grade": "1.00000",
            "grade_formatted": "F",
            "feedback": "",
            "information": "",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "timemodified": "onsdag, 7 december 2016, 4:40 "
        }
    ]
}