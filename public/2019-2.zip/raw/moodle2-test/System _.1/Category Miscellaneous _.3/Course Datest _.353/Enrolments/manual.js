var data_file_30 = {
    "0": {
        "status": "0",
        "timecreated": "tisdag, 6 december 2016, 10:42 ",
        "timemodified": "tisdag, 6 december 2016, 10:42 ",
        "timestart": "tisdag, 6 december 2016, 12:00 ",
        "timeend": "torsdag, 1 januari 1970, 1:00 "
    }
}