var data_file_3 = {
    "commenttext": "<p>Test<\/p><p>This is test<\/p><p>Some text<\/p><p>Some added text<\/p>"
}