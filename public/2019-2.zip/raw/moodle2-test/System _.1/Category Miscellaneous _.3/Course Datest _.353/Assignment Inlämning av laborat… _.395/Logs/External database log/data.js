var data_file_19 = {
    "logs": [
        {
            "name": "Grading form viewed",
            "description": "The user with id '5' viewed the grading form for the user with id '2020' for the assignment with course module id '240'.",
            "timecreated": "onsdag, 7 december 2016, 4:38 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "assignid": "45"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "The submission has been graded.",
            "description": "The user with id '5' has graded the submission '1968' for the user with id '2020' for the assignment with course module id '240'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Standard web request",
            "ip": "",
            "other": [],
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Grading form viewed",
            "description": "The user with id '5' viewed the grading form for the user with id '2020' for the assignment with course module id '240'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "assignid": "45"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}