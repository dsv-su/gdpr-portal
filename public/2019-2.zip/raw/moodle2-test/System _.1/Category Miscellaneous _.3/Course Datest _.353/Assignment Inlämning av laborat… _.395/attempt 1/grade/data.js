var data_file_4 = {
    "timecreated": "onsdag, 7 december 2016, 4:38 ",
    "timemodified": "onsdag, 7 december 2016, 4:40 ",
    "grader": 5,
    "grade": "2.00000",
    "attemptnumber": 1
}