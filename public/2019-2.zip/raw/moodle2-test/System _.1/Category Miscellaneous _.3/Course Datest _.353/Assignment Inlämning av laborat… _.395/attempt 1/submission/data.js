var data_file_2 = {
    "timecreated": "onsdag, 7 december 2016, 4:38 ",
    "timemodified": "onsdag, 7 december 2016, 4:38 ",
    "status": "No submission",
    "groupid": "0",
    "attemptnumber": 1,
    "latest": "No"
}