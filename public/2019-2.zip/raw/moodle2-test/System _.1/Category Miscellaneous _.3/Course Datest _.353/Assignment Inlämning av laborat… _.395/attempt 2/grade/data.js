var data_file_6 = {
    "timecreated": "onsdag, 7 december 2016, 4:40 ",
    "timemodified": "onsdag, 7 december 2016, 4:40 ",
    "grader": 5,
    "grade": "-1.00000",
    "attemptnumber": 2
}