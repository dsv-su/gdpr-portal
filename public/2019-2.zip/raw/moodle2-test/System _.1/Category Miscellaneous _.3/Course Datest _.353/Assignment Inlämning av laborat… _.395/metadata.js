var data_file_7 = {
    "mailed": {
        "value": "Yes",
        "description": "Has this user been mailed yet?"
    }
}