var data_file_44 = {
    "fullname": "Datest",
    "shortname": "DTST",
    "idnumber": "",
    "summary": "",
    "format": "Weekly format",
    "startdate": "fredag, 21 december 2012, 12:00 ",
    "enddate": "fredag, 1 mars 2013, 2:00 "
}