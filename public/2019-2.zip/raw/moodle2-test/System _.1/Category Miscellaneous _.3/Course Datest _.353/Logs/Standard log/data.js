var data_file_25 = {
    "logs": [
        {
            "name": "User enrolled in course",
            "description": "The user with id '5' enrolled the user with id '2020' using the enrolment method 'manual' in the course with id '15'.",
            "timecreated": "tisdag, 6 december 2016, 10:42 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "enrol": "manual"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Role assigned",
            "description": "The user with id '5' assigned the role with id '5' to the user with id '2020'.",
            "timecreated": "tisdag, 6 december 2016, 10:42 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "id": 2986,
                "component": "",
                "itemid": 0
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User graded",
            "description": "The user with id '5' updated the grade with id '4788' for the user with id '2020' for the grade item with id '86'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "itemid": "86",
                "overridden": false,
                "finalgrade": "2.00000"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User graded",
            "description": "The user with id '5' updated the grade with id '4789' for the user with id '2020' for the grade item with id '91'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "itemid": "91",
                "overridden": false,
                "finalgrade": 1
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User graded",
            "description": "The user with id '5' updated the grade with id '4790' for the user with id '2020' for the grade item with id '80'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "itemid": "80",
                "overridden": false,
                "finalgrade": null
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}