var data_file_22 = {
    "logs": [
        {
            "name": "Role assigned",
            "description": "The user with id '5' assigned the role with id '4' to the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "id": 3079,
                "component": "",
                "itemid": 0
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}