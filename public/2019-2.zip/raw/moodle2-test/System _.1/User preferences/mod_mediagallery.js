var data_file_41 = {
    "mod_mediagallery_mediasize": {
        "value": "1",
        "description": "Medium"
    }
}