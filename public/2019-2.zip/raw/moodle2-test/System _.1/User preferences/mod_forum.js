var data_file_40 = {
    "maildigest": {
        "value": "0",
        "description": "No digest (single email per forum post)"
    },
    "autosubscribe": {
        "value": "1",
        "description": "Yes: when I post, subscribe me to that forum discussion"
    },
    "trackforums": {
        "value": "0",
        "description": "No: don't keep track of posts I have seen"
    },
    "forum_discussionlistsortorder": {
        "value": "1",
        "description": "Sort by last post creation date in descending order"
    }
}