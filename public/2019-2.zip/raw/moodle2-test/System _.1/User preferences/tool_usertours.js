var data_file_43 = {
    "tool_usertours_tour_completion_time_4": {
        "value": "m\u00e5ndag, 18 november 2019, 11:34 ",
        "description": "You last marked the \"Dashboard\" user tour as completed on m\u00e5ndag, 18 november 2019, 11:34 "
    }
}