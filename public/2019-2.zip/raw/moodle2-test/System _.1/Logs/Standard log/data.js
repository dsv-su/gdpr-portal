var data_file_21 = {
    "logs": [
        {
            "name": "User has logged in",
            "description": "The user with id '2020' has logged in.",
            "timecreated": "m\u00e5ndag, 20 juni 2016, 4:17 ",
            "origin": "Standard web request",
            "ip": "193.11.92.96",
            "other": {
                "username": "tdsv@su.se"
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Message sent",
            "description": "The user with id '5' sent a message to the user with id '2020'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "messageid": 28
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Message sent",
            "description": "The user with id '5' sent a message to the user with id '2020'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "messageid": 29
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User has logged in",
            "description": "The user with id '2020' has logged in.",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": {
                "username": "tdsv@su.se"
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "User logged in as another user",
            "description": "The user with id '5' has logged in as the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:14 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "originalusername": "Pavel Sokolov",
                "loggedinasusername": "Test1 DSV"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User has logged in",
            "description": "The user with id '2020' has logged in.",
            "timecreated": "fredag, 19 januari 2018, 4:26 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": {
                "username": "tdsv@su.se"
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '5' sent a notification to the user with id '2020'.",
            "timecreated": "fredag, 8 november 2019, 1:46 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '4309' sent a notification to the user with id '2020'.",
            "timecreated": "fredag, 8 november 2019, 2:27 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 4309,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '5' sent a notification to the user with id '2020'.",
            "timecreated": "fredag, 8 november 2019, 2:28 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '5' sent a notification to the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 11 november 2019, 5:30 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '5' sent a notification to the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 11 november 2019, 5:36 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '5' sent a notification to the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 11 november 2019, 5:41 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "m\u00e5ndag, 18 november 2019, 11:12 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "torsdag, 21 november 2019, 3:03 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "torsdag, 21 november 2019, 3:14 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "torsdag, 21 november 2019, 3:15 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "fredag, 22 november 2019, 5:37 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "torsdag, 5 december 2019, 3:25 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}