var data_file_14 = {
    "logs": [
        {
            "name": "Message sent",
            "description": "The user with id '5' sent a message to the user with id '2020'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "messageid": 28
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Message sent",
            "description": "The user with id '5' sent a message to the user with id '2020'.",
            "timecreated": "onsdag, 7 december 2016, 4:40 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "messageid": 29
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "User has logged in",
            "description": "The user with id '2020' has logged in.",
            "timecreated": "tisdag, 21 mars 2017, 9:11 ",
            "origin": "Standard web request",
            "ip": "130.237.161.22",
            "other": {
                "username": "tdsv@su.se"
            },
            "authorid": 2020,
            "author_of_the_action_was_you": "Yes"
        },
        {
            "name": "User logged in as another user",
            "description": "The user with id '5' has logged in as the user with id '2020'.",
            "timecreated": "tisdag, 21 mars 2017, 9:14 ",
            "origin": "Standard web request",
            "ip": "",
            "other": {
                "originalusername": "Pavel Sokolov",
                "loggedinasusername": "Test1 DSV"
            },
            "authorid": 5,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        },
        {
            "name": "Notification sent",
            "description": "The user with id '2' sent a notification to the user with id '2020'.",
            "timecreated": "torsdag, 5 december 2019, 3:25 ",
            "origin": "Command line tool",
            "ip": "",
            "other": {
                "courseid": "1"
            },
            "authorid": 2,
            "author_of_the_action_was_you": "No",
            "relateduserid": 2020,
            "related_user_was_you": "Yes"
        }
    ]
}